<link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/library/css/options.css" type="text/css" media="screen" />
<script src="<?php bloginfo('wpurl'); ?>/wp-includes/js/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php bloginfo('template_directory'); ?>/library/js/crir.js" type="text/javascript"></script>
<script src="<?php bloginfo('template_directory'); ?>/library/js/options.js" type="text/javascript"></script>