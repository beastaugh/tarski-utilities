<div class="secondary">
	<p><a class="feed" href="<?php bloginfo($feed_url); ?>"><?php _e('Subscribe to feed','tarski'); ?></a></p>
</div>