<div class="entry">
	
	<div class="meta">
		<h1 class="title"><?php _e('Sorry','tarski'); ?></h1>
	</div>
	
	<div class="content">
		<p><?php _e('Looks like there&#8127;s nothing here, sorry. You might want to try the search function. Alternatively, return to the ','tarski'); ?><a href="<?php echo get_bloginfo('url'); ?>/"><?php _e('front page','tarski'); ?></a><?php _e('.','tarski'); ?></p>
	</div>
	
</div> <!-- /entry -->