<div class="widgets">
	<?php dynamic_sidebar('sidebar-2'); ?>
</div>