<div class="widgets">
	<?php dynamic_sidebar('sidebar-post-and-page'); ?>
</div>