<div class="widgets">
	<?php dynamic_sidebar('sidebar-1'); ?>
</div>